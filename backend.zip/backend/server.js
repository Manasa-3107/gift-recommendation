const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const OpenAI = require('openai');

dotenv.config();
const app = express();
const USD_TO_INR = 83;

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(cors({
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true
}));
app.use(express.json());

const PORT = process.env.PORT || 5000;

app.get('/', (req, res) => {
    res.json({ message: 'Gift Recommendation API is running' });
});

app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.post('/api/recommendations', async (req, res) => {
    try {
        const { preferences } = req.body;
        console.log('Received preferences:', preferences);
        
        if (!preferences || !preferences.interests || !preferences.occasion || !preferences.budget) {
            throw new Error('Missing required preferences');
        }

        preferences.budget = parseFloat(preferences.budget);
        
        try {
            const aiRecommendations = await getAIRecommendations(preferences);
            if (aiRecommendations && aiRecommendations.length > 0) {
                console.log('Sending AI recommendations:', aiRecommendations);
                return res.json(aiRecommendations);
            }
        } catch (aiError) {
            console.error('AI recommendation error:', aiError);
        }
        
        const recommendations = generateRecommendations(preferences);
        console.log('Sending static recommendations:', recommendations);
        res.json(recommendations);
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: error.message });
    }
});

async function getAIRecommendations(preferences) {
    const budgetUSD = preferences.budget;
    const budgetINR = Math.round(budgetUSD * USD_TO_INR);
    
    const prompt = `As a gift recommendation expert, suggest 3 unique gift ideas for someone with these preferences:
        - Occasion: ${preferences.occasion}
        - Age: ${preferences.age}
        - Interests: ${preferences.interests}
        - Budget: ₹${budgetINR}

        For each gift, provide:
        1. Name and exact price in INR (must be under ₹${budgetINR})
        2. A brief description
        3. Why it matches their interests

        Format each suggestion as:
        Gift Name - ₹XX,XXX
        Description and reasoning`;

    const completion = await openai.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "gpt-3.5-turbo",
        temperature: 0.7,
        max_tokens: 500
    });

    const response = completion.choices[0].message.content;
    return parseAIResponse(response, budgetINR);
}

function parseAIResponse(response, maxBudget) {
    try {
        const gifts = response.split(/\d+\./).filter(gift => gift.trim());
        
        return gifts.map(gift => {
            const lines = gift.trim().split('\n');
            const firstLine = lines[0];
            
            const nameMatch = firstLine.match(/^(.+?)\s*-\s*₹(\d+(?:,\d+)*(\.\d{2})?)/);
            if (!nameMatch) return null;

            const name = nameMatch[1].trim();
            const priceINR = parseFloat(nameMatch[2].replace(/,/g, ''));
            const description = lines.slice(1).join(' ').trim();

            if (priceINR > maxBudget) return null;

            return { 
                name, 
                description,
                price: priceINR,
                priceFormatted: `₹${priceINR.toLocaleString('en-IN')}`
            };
        }).filter(gift => gift && gift.name && gift.price > 0);
    } catch (error) {
        console.error('Error parsing AI response:', error);
        return [];
    }
}

function generateRecommendations(preferences) {
    const { interests, budget, occasion, age } = preferences;
    console.log('Processing interests:', interests);

    const occasionGifts = {
        'birthday': [
            { name: "Personalized Birthday Gift Box", description: "Custom curated gift box with personalized items", priceINR: 7500 },
            { name: "Experience Day Package", description: "Choice of exciting experiences and adventures", priceINR: 12500 }
        ],
        'christmas': [
            { name: "Holiday Special Bundle", description: "Premium holiday-themed gift collection", priceINR: 10800 },
            { name: "Festive Gift Set", description: "Luxury Christmas-themed items and treats", priceINR: 8300 }
        ],
        'anniversary': [
            { name: "Couples Gift Set", description: "Romantic gift package for couples", priceINR: 15000 },
            { name: "Memory Book Bundle", description: "Custom photo album with premium accessories", priceINR: 9900 }
        ]
    };

    const giftIdeas = {
        'read': [
            { name: "Kindle Paperwhite E-reader", description: "Perfect for book lovers", priceINR: 11600 },
            { name: "Book Subscription Box", description: "Monthly curated books", priceINR: 2500 }
        ],
        'game': [
            { name: "Gaming Headset", description: "High-quality gaming headset", priceINR: 7500 },
            { name: "Gaming Console", description: "Latest gaming console", priceINR: 25000 }
        ],
        'music': [
            { name: "Wireless Earbuds", description: "Premium wireless earbuds", priceINR: 12500 },
            { name: "Digital Piano", description: "Professional-grade digital piano", priceINR: 58000 }
        ],
        'sport': [
            { name: "Smart Fitness Watch", description: "Track workouts and health", priceINR: 15000 },
            { name: "Premium Sports Equipment", description: "High-quality gear", priceINR: 10800 }
        ],
        'tech': [
            { name: "Smart Watch", description: "Feature-rich smartwatch", priceINR: 16600 },
            { name: "Drone Kit", description: "Professional camera drone", priceINR: 33200 }
        ]
    };

    let recommendations = [];

    if (occasion && occasionGifts[occasion]) {
        recommendations.push(...occasionGifts[occasion]);
    }

    if (interests) {
        const interestsList = interests.toLowerCase().split(',').map(i => i.trim());
        
        interestsList.forEach(interest => {
            Object.keys(giftIdeas).forEach(category => {
                if (interest.includes(category)) {
                    recommendations.push(...giftIdeas[category]);
                }
            });
        });
    }

    if (recommendations.length === 0) {
        recommendations = [
            { name: "Premium Gift Card", description: "Versatile gift card", priceINR: 12500 },
            { name: "Experience Voucher", description: "Choice of experiences", priceINR: 16600 }
        ];
    }

    recommendations = recommendations.map(gift => ({
        ...gift,
        price: gift.priceINR,
        priceFormatted: `₹${gift.priceINR.toLocaleString('en-IN')}`
    }));

    if (budget) {
        const budgetINR = Math.round(budget * USD_TO_INR);
        recommendations = recommendations.filter(gift => gift.price <= budgetINR);
        
        if (recommendations.length === 0) {
            const fallbackPrice = Math.round(budgetINR * 0.9);
            recommendations.push({
                name: "Gift Card",
                description: "Flexible gift card option",
                price: fallbackPrice,
                priceFormatted: `₹${fallbackPrice.toLocaleString('en-IN')}`
            });
        }
    }

    return [...new Set(recommendations.map(JSON.stringify))]
        .map(JSON.parse)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
}

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`OpenAI API Key ${process.env.OPENAI_API_KEY ? 'is' : 'is not'} configured`);
});