import React, { useState } from 'react';
import { 
    Box, 
    TextField, 
    Button, 
    Typography, 
    Paper,
    FormControl,
    InputLabel,
    Select,
    MenuItem
} from '@mui/material';

const Questionnaire = ({ onSubmit }) => {
    const [formData, setFormData] = useState({
        recipientName: '',
        age: '',
        occasion: '',
        interests: '',
        budget: '',
        relationship: ''
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <Paper elevation={3} sx={{ p: 3, maxWidth: 600, mx: 'auto', mt: 4 }}>
            <Typography variant="h5" gutterBottom>
                Gift Recommendation Questionnaire
            </Typography>
            <Box component="form" onSubmit={handleSubmit}>
                <TextField
                    fullWidth
                    label="Recipient's Name"
                    name="recipientName"
                    value={formData.recipientName}
                    onChange={handleChange}
                    margin="normal"
                />
                <TextField
                    fullWidth
                    label="Age"
                    name="age"
                    type="number"
                    value={formData.age}
                    onChange={handleChange}
                    margin="normal"
                />
                <FormControl fullWidth margin="normal">
                    <InputLabel>Occasion</InputLabel>
                    <Select
                        name="occasion"
                        value={formData.occasion}
                        onChange={handleChange}
                        label="Occasion"
                    >
                        <MenuItem value="birthday">Birthday</MenuItem>
                        <MenuItem value="christmas">Christmas</MenuItem>
                        <MenuItem value="anniversary">Anniversary</MenuItem>
                        <MenuItem value="other">Other</MenuItem>
                    </Select>
                </FormControl>
                <TextField
                    fullWidth
                    label="Interests/Hobbies"
                    name="interests"
                    multiline
                    rows={3}
                    value={formData.interests}
                    onChange={handleChange}
                    margin="normal"
                />
                <TextField
                    fullWidth
                    label="Budget"
                    name="budget"
                    type="number"
                    value={formData.budget}
                    onChange={handleChange}
                    margin="normal"
                />
                <Button 
                    variant="contained" 
                    color="primary" 
                    type="submit"
                    sx={{ mt: 2 }}
                    fullWidth
                >
                    Get Recommendations
                </Button>
            </Box>
        </Paper>
    );
};

export default Questionnaire;