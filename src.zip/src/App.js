import React, { useState } from 'react';
import { Container, Typography, Box, TextField, Button, Select, MenuItem, FormControl, InputLabel, CircularProgress, Alert } from '@mui/material';

function App() {
  const [formData, setFormData] = useState({
    recipientName: '',
    age: '',
    occasion: '',
    interests: '',
    budget: ''
  });
  const [recommendations, setRecommendations] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      console.log('Sending request with data:', formData);
      
      // Add timeout to the fetch request
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch('http://localhost:5000/api/recommendations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          preferences: {
            ...formData,
            age: parseInt(formData.age),
            budget: parseFloat(formData.budget)
          }
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      console.log('Response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error: ${errorText}`);
      }

      const data = await response.json();
      console.log('Received recommendations:', data);
      setRecommendations(data);
    } catch (error) {
      console.error('Error details:', error);
      if (error.name === 'AbortError') {
        setError('Connection timeout. Please check if the server is running at http://localhost:5000');
      } else if (error.message.includes('Failed to fetch')) {
        setError('Unable to connect to the server. Please make sure the backend server is running on port 5000');
      } else {
        setError(`Error: ${error.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const isFormValid = () => {
    return formData.interests && formData.occasion && formData.budget;
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center" sx={{ color: 'primary.main' }}>
          Gift Recommendation System
        </Typography>

        <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <TextField
            required
            fullWidth
            margin="normal"
            name="recipientName"
            label="Recipient's Name"
            value={formData.recipientName}
            onChange={handleChange}
            sx={{ mb: 2 }}
          />
          
          <TextField
            required
            fullWidth
            margin="normal"
            name="age"
            label="Age"
            type="number"
            value={formData.age}
            onChange={handleChange}
            inputProps={{ min: 0, max: 120 }}
            sx={{ mb: 2 }}
          />

          <FormControl required fullWidth margin="normal" sx={{ mb: 2 }}>
            <InputLabel>Occasion</InputLabel>
            <Select
              name="occasion"
              value={formData.occasion}
              onChange={handleChange}
              label="Occasion"
            >
              <MenuItem value="birthday">Birthday</MenuItem>
              <MenuItem value="christmas">Christmas</MenuItem>
              <MenuItem value="anniversary">Anniversary</MenuItem>
            </Select>
          </FormControl>

          <TextField
            required
            fullWidth
            margin="normal"
            name="interests"
            label="Interests (comma-separated)"
            value={formData.interests}
            onChange={handleChange}
            helperText="Example: reading, gaming, music, sports, art, tech"
            sx={{ mb: 2 }}
          />

          <TextField
            required
            fullWidth
            margin="normal"
            name="budget"
            label="Budget ($)"
            type="number"
            value={formData.budget}
            onChange={handleChange}
            inputProps={{ min: 0 }}
            sx={{ mb: 3 }}
          />

          <Button
            type="submit"
            fullWidth
            variant="contained"
            disabled={!isFormValid() || loading}
            sx={{ 
              mt: 3, 
              mb: 2,
              height: 48,
              fontSize: '1.1rem'
            }}
          >
            {loading ? <CircularProgress size={24} /> : 'Get Recommendations'}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}

        {recommendations.length > 0 && (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h5" gutterBottom sx={{ color: 'primary.main' }}>
              Recommended Gifts for {formData.recipientName}
            </Typography>
            {recommendations.map((gift, index) => (
              <Box 
                key={index} 
                sx={{ 
                  mb: 2, 
                  p: 3, 
                  border: '1px solid #ddd', 
                  borderRadius: 2,
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  '&:hover': {
                    boxShadow: '0 4px 8px rgba(0,0,0,0.15)',
                    transform: 'translateY(-2px)',
                    transition: 'all 0.3s ease'
                  }
                }}
              >
                <Typography variant="h6" color="primary">{gift.name}</Typography>
                <Typography variant="body1" sx={{ my: 1 }}>{gift.description}</Typography>
                <Typography variant="h6" color="success.main">
                  ${gift.price.toFixed(2)}
                </Typography>
              </Box>
            ))}
          </Box>
        )}
      </Box>
    </Container>
  );
}

export default App;